package ru.kraser.kafka_wikimedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaWikimediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
