package ru.kraser.kafka_wikimedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaWikimediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaWikimediaApplication.class, args);
	}

}
